<div align="center">
<img src="https://github.com/nvimdev/lspsaga.nvim/assets/41671631/682a189e-6571-48f8-af1c-1e52142c7071" width="20%" height="20%"/>
</div>

Improve lsp experiences in neovim

[![](https://img.shields.io/badge/Element-0DBD8B?style=for-the-badge&logo=element&logoColor=white)](https://matrix.to/#/#lspsaga-nvim:matrix.org)

[Usage see the doc website](https://nvimdev.github.io/lspsaga/)

# Donate

Currently, I am in need of some donations. If you'd like to support my work financially, please donate through Github Sponsor button or
[PayPal](https://paypal.me/bobbyhub) [wechat or Alipay](https://user-images.githubusercontent.com/41671631/219828224-8834f48a-0769-45d0-a6b9-1e7f38642fcf.png)


# License

Licensed under the [MIT](./LICENSE) license.
