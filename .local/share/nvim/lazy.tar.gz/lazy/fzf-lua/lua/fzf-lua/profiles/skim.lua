return {
  { "default-title" }, -- base profile
  desc = "fzf-lua defaults with `sk` as binary",
  fzf_bin = "sk",
  defaults = { compat_warn = false },
}
