local M = {
    NAME_PREFIX = "Scrollbar",
    NAME_SUFFIX = "Handle",
    BUF_VAR_KEY = "scrollbar_marks",
}

return M
