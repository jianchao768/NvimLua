return {
    ["dummy"] = "dummy-registry.dummy_package",
    ["dummy2"] = "dummy-registry.dummy2_package",
    ["registry"] = "dummy-registry.registry_package",
}
