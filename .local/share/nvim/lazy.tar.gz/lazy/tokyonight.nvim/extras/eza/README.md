<h3 align="center">
	Tokyonight for <a href="https://github.com/eza-community/eza">eza</a>
</h3>

### About

A Tokyonight theme for `eza`, a modern replacement for `ls`.

### Usage

1. Copy to `~/.config/eza/theme.yml`

Note: on MacOS, `eza` will look for the theme file in `~/Library/Application Support/eza` by default. That directory can be overridden by setting `EZA_CONFIG_DIR`.

For more information, see [eza-themes](https://github.com/eza-community/eza-themes)
