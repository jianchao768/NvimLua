To use any of these themes in Ghostty, just clone the tokyonight repo
and set the theme to the absolute path of the theme file.

Example:

```ini
theme = "/home/folke/projects/tokyonight.nvim/extras/ghostty/tokyonight_night"
```
