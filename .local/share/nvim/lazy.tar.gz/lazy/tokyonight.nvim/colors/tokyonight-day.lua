require("tokyonight").load({ style = "day" })
